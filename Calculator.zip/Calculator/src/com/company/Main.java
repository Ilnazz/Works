package com.company;

import java.util.Map;
import java.util.TreeMap;

public class Main {
    /**
     * Дерево для хранения соответствий римских чисел арабским числам
     */
    private final static TreeMap<Integer, String> romanValuesOfArabics = new TreeMap<Integer, String>();

    // Инициализация дерева соответствиями римских чисел арабским числам
    static {
        romanValuesOfArabics.put(1000, "M");
        romanValuesOfArabics.put(900, "CM");
        romanValuesOfArabics.put(500, "D");
        romanValuesOfArabics.put(400, "CD");
        romanValuesOfArabics.put(100, "C");
        romanValuesOfArabics.put(90, "XC");
        romanValuesOfArabics.put(50, "L");
        romanValuesOfArabics.put(40, "XL");
        romanValuesOfArabics.put(10, "X");
        romanValuesOfArabics.put(9, "IX");
        romanValuesOfArabics.put(5, "V");
        romanValuesOfArabics.put(4, "IV");
        romanValuesOfArabics.put(1, "I");
    }

    /**
     * Проверяет, является ли строка числом, заданным римскими цифрами
     * @param s строка для проверки
     * @return результат проверки
     */
    public static Boolean isRoman(String s)
    {
        for (char c : s.toCharArray())
        {
            if (!(c == 'I' || c == 'V' || c == 'X' || c == 'L' || c == 'C' || c == 'M'))
                return false;
        }
        return true;
    }

    /**
     * Преобразует число, заданное арабскими цифрами в число, записанное римскими цифрами
     * @param arabic число, заданное арабскими цифрами
     * @return число, записанное римскими цифрами
     */
    public static String toRoman(int arabic) {
        int l =  romanValuesOfArabics.floorKey(arabic);
        if ( arabic == l ) {
            return romanValuesOfArabics.get(arabic);
        }
        return romanValuesOfArabics.get(l) + toRoman(arabic-l);
    }

    /**
     * Проверяет, является ли строка числом, заданным арабскими цифрами
     * @param s строка для проверки
     * @return результат проверки
     */
    public static Boolean isArabic(String s) {
        try {
            int n = Integer.parseInt(s);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * Преобразует число, заданным римскими цифрами в число записанное арабскими цифрами
     * @param roman строка, содержащая число, заданное римскими цифрами
     * @return число, записанное арабскими цифрами
     */
    public static int toArabic(String roman) {
        Map<Character, Integer> romanDigits = Map.of(
                'I', 1 ,
                'V', 5,
                'X', 10,
                'L', 50,
                'C', 100,
                'D', 500,
                'M', 1000
        );

        int arabic = 0;
        int previous = 0;
        char romanDigit;
        for (int i = roman.length()-1; i >= 0; i--) {
            romanDigit = roman.charAt(i);
            int current = romanDigits.get(romanDigit);
            if (current >= previous)
                arabic += current;
            else
                arabic -= current;

            previous = current;
        }

        return arabic;
    }

    /**
     * Проверяет, является ли строка оператором +, -, *, /
     * @param s любая строка
     * @return результат проверки
     */
    public static Boolean isOperator(String s) {
        return (s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/"));
    }

    /**
     * Применяет оператор к двум числам
     * @param operator строка, являющаяся оператором
     * @param first первое число, заданное арабскими цифрами
     * @param second второе число, заданное арабскими цифрами
     * @return результат операции над числами first и second
     */
    public static int applyOperator(String operator, int first, int second) {
        return switch (operator) {
            case "+" -> first + second;
            case "-" -> first - second;
            case "*" -> first * second;
            case "/" -> first / second;
            default -> throw new RuntimeException(String.format("Неверный оператор: <%s>. Допустимые операторы: +, -, *, /.", operator));
        };
    }

    /**
     * Вычисляет выражение в формате <число1> <оператор> <число2>,
     * где число1, число2 - числа, заданные арабскими или римскими цифрами, принадлежат [1;10];
     *     оператор - один из: +, -, *, /.
     * @param input строка, содержащая выражение
     * @return результат выражения
     */
    public static String calc(String input) {
        // Проверка на пустое выражение
        if (input == null || input.trim().isEmpty())
            throw new RuntimeException("Выражение не должно быть пустым.");

        // Проверка на переносы строки в выражении
        if (input.contains("\n"))
            throw new RuntimeException("Выражение не должно содержать переноса строки (\\n).");

        // Разбиение выражение на части
        String[] parts = input.split("\\s+");

        // Проверка выражения соответствие формату <число1> <оператор> <число2>
        if (parts.length != 3)
            throw new RuntimeException("Выражение должно быть задано в следующем формате: <число1> <оператор> <число2>,\n" +
                    "где число1,число2 - должны быть заданы арабскими или римскими цифрами и принадлежать [1;10];\n" +
                    "    оператор - должен быть одним из: +, -, * или /.");

        String first = parts[0], // первое число
                operator = parts[1], // оператор
                second = parts[2]; // второе число

        // Проверка на правилность оператора
        if (!isOperator(operator))
            throw new RuntimeException(String.format("Неверный оператор: <%s>. Допустимые операторы: +, -, *, /.", operator));

        String result = ""; // переменная, для хранения результата выражения

        // Обрабатывается 4 возможных случая.
        if (isArabic(first) && isArabic(second)) { // 1-ый случай: оба числа заданы арабскими цифрами
            // Преобразование чисел, заданных строками в целочисленный тип
            int a = Integer.parseInt(first),
                    b = Integer.parseInt(second);

            // Проверка чисел на соответствие требованиям
            if ((a < 1 || a > 10) || (b < 1 || b > 10))
                throw new RuntimeException("Числа должны быть в диапазоне [1;10].");

            // Вычисление целочисленного результата операции над числами
            int intResult = applyOperator(operator, a, b);

            // Преобразование результата в строковый тип и запись в переменную result
            result = Integer.toString(intResult);

        } else if (isRoman(first) && isRoman(second)) { // 2-ой случай: оба числа заданы римскими цифрами
            // Преобразование чисел, заданных строками в целочисленный тип
            int a = toArabic(first),
                    b = toArabic(second);

            // Проверка чисел на соответствие требованиям
            if (a > 10 || b > 10)
                throw new RuntimeException("Числа должны быть в диапазоне [I;X].");

            // Вычисление целочисленного результата операции над числами
            int intResult = applyOperator(operator, a, b);

            // Проверка результата на соответствие требованиям
            if (intResult < 1)
                throw new RuntimeException("Результат операции с римскими числами должен быть >= 1.");

            // Преобразование результата в строковый тип и запись в переменную result
            result = Integer.toString(intResult);

        } else if ((isArabic(first) && isRoman(second))
                || (isRoman(first) && isArabic(second))) { // 3-ий случай: числа заданы по-разному
            throw new RuntimeException("Оба числа должны быть заданы с помощью одних цифр - арабскими или римскими");
        } else { // 4-ый случай: числа заданы неверно
            throw new RuntimeException("Неправильные числа. Числа должны быть заданы с помощью арабских или римских цифр.");
        }

        // Возврат результата выражения
        return result;
    }

    /**
     * Точка входа программы. Тестирование функции calc
     * @param args аргументы командной строки
     */
    public static void main(String[] args) {
        // Тест функции calc.
        String[] expressions = { // выражения
                "10 + 10",
                "10 - 10",
                "10 * 10",
                "10 / 3",
                "X + X",
                "X - IX",
                "X * III",
                "X / III"
        };
        // Для каждого выражения применить функцию calc и вывести результат
        for (String expr : expressions) {
            System.out.printf("%s = %s.\n", expr, calc(expr));
        }
    }
}
